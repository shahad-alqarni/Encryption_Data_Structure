
package homework;

public class Cipher {
    
    Character []Letters ={'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'}; 
    
    /*
    ALGORITHM encooder(original ,number):
    //original is the plain text before encryption
    // number is the number of letters that the encoder moves by to forward
    original=original.toUpperCase()
    codeString=""
         FOR i=0 to original.length() DO
              letter= original.charAt(i)
               IF(original.charAt(i)=' ') codeString=codeString+" "
               END IF
                      FOR j=0 to Letters.length() DO 
                                 IF(letter=(Letters[j])) DO
                                codeString=codeString+Letters[(j+number)%Letters.length];
                                 END IF
                      END FOR
        END FOR
    RETURN codeString
    END
    */
    public String encooder (String original , int number){
        
        original=original.toUpperCase();//to convert the string the user written to capital
        String codeString=""; // the varible we will put the encryption in
        
        for(int i=0;i<original.length();i++){  // loop to find the char to start
            char  letter= original.charAt(i);
            
            if(original.charAt(i)==' ') {
                codeString=codeString+" ";}
            
            for(int j=0;j<Letters.length;j++){ //loop  To encode characters
                
                if(letter==(Letters[j])) 
                    codeString=codeString+Letters[(j+number)%Letters.length];}}
        
        return codeString;}
    
    
//----------------------------------------------------------------------------------------
    
    
    /*ALGORITHM decoder ( original ,number):
    //original is the cipher text after encryption
    //number is the number of letters that the decoder moves by to backward
      original=original.toUpperCase()
       codeString=""
         FOR i=0 to original.length() DO
            letter= original.charAt(i); 
                IF(original.charAt(i)=' ') codeString=codeString+" "
                 END IF
                     FOR j=0 to Letters.length() DO 
                                    IF(letter=(Letters[j])) 
                                          IF((j-number)>=0) 
                                          codeString=codeString+Letters[(j-number)];
                                          
                                           ELSE 
                                           codeString=codeString+Letters[(j-number+Letters.length)];
                                           END IF
                                    END IF
                     END FOR
         END FOR
    RETURN codeString
    END
    */
    public String decoder (String original , int number){//encryption to backword
        
        original=original.toUpperCase();//to convert the string the user written to capital
        String codeString=""; // the varible we will put the encryption in
        
        for(int i=0;i<original.length();i++){  // loop to find the char to start
            char  letter= original.charAt(i); 
            
            if(original.charAt(i)==' ') {
                codeString=codeString+" ";}
            
            for(int j=0;j<Letters.length;j++){ //loop  To encode characters
                
                if(letter==(Letters[j])){ 
                    if((j-number)>=0)
                        codeString=codeString+Letters[(j-number)];
                    else
                       codeString=codeString+Letters[(j-number+Letters.length)];}}}
        
        return codeString;}
    
}
