
package homework;


public class Duplicate <E>{
    
    Node head = null;
    
    
    public void add(E data){
        
        Node newNode =new Node (data) ;
        
        if(head==null)  {
            newNode.next=newNode;
            head=newNode;}
        else{
            newNode.next=head.next;
            head.next=newNode;}
    }
    
    
    public boolean  checkDuplicate (Node<E> data) {  
        
        boolean isDUBLICATE= false;
        Node current = head; 
        Node moving = null; 
        
        if(head == null)   
            System.out.println("THE CIRCULAR LINKED LIST IS EMPTY :("); 
        
        else { 
            while(current.next != head){
                moving = current.next;
                
                while(moving != head){
                    
                    if(current.data.equals( moving.data)){
                        isDUBLICATE=true;
                        return isDUBLICATE;}
                    moving= moving.next;} 
                
                current =current.next;}}
        
        return isDUBLICATE;}  
    
    
   

}
