// ألاء عبدالله عوض باقندوان >> 439010950
// شهد عبدالله علي القرني>>  
package homework;

import java.util.Scanner;

public class Homework {
    
    public static void main(String[] args) {
        
        Scanner input=new Scanner(System.in);
        
        Cipher ci= new Cipher();
        Duplicate<String> du = new Duplicate();
        SingleyLinkedList<String> sl = new SingleyLinkedList();
        
        int choice;      
        int n;
        
        while(true){
            System.out.println("\n *** MENU***\n"+
                               "1. Cryptography\n" +
                               "2. CheckDuplicate\n" +
                               "3. Reverse\n" +
                               "4. Exit"+
                               "\nENTER YOUR CHOICE PLEASE : ");
            
            choice = input.nextInt();
            
            switch(choice){
                case 1:
                    System.out.print("ENTER THE ENCRYPTION NUMBER : ");
                    int num=input.nextInt();
                    input.nextLine();
                    
                    System.out.print("\nPLAIN TEXT: ");
                    String c= input.nextLine();
                    String f=ci.encooder(c,num);
                    
                    System.out.println("\nDO YOU WANT ENCRYPTION :\n"
                                     + "1-LOWER CASE\n"
                                     + "2-UPPER CASE\n");
                    n=input.nextInt();
                    System.out.print("\nGOOD CHOICE MISS :)\n");
                    if (n==1){
                        System.out.print("\nCIPHER TEXT: ");
                        System.out.println(f.toLowerCase());
                        String de=ci.decoder(f, num);
                        System.out.print("BACK TO PLAIN TEXT: ");
                        System.out.print(de.toLowerCase()+"\n");}
                    
                    else if(n==2){ System.out.print("CIPHER TEXT: ");
                    System.out.println(f.toUpperCase());
                    String de=ci.decoder(f, num);
                    System.out.print("BACK TO PLAIN TEXT: ");
                    System.out.print(de.toUpperCase()+"\n");}
                    break;
                    
                    
                case 2: 
                    System.out.print("\nENTER THE NUMBER OF WORDS YOU WANT TO ADD :");
                    n=input.nextInt();
                    System.out.println("\n");
                    
                    for(int i=0;i<n;i++){
                        System.out.print("WRITE THE WORD PLEASE : ");
                        String ad= input.next();
                        du.add(ad);}
                    
                    System.out.println("\nDO YOU WANT >>\n"
                                     + "1-CHECK DUPLICATE ?\n"
                                     + "2-NO THX :)\n");
                    int choisee=input.nextInt();
                    boolean chec=du.checkDuplicate(du.head);
                    
                    if (choisee==1){
                        if(chec==true){
                            System.out.println("\n"+chec);
                            System.out.println("WE FOUND DUPLICATE :) ");}
                        
                        else{
                            System.out.println("\n"+chec);
                            System.out.println("THERE IS NO DUPLICATE :)");}
                        break;}
                    
                    else{
                        break;}
                    
                    
                case 3: 
                    System.out.print("\nENTER THE STATEMENT YOU WANT TO REVERSE IT : ");
                    input.nextLine();
          
                    String y= input.nextLine();
                    String t=" "+y+" ";
                    int r=0;
                    
                    for(int i=0;i<t.length();i++){
                        if(t.charAt(i)==' '){
                        sl.addLast(t.substring(r,i+1));
                        r=i;}}
                     
                    System.out.println("\nDO YOU WANT >>\n"
                                     + "1-REVERSE THE WORDS ?\n"
                                     + "2-NO THX :)\n");
                   
                    int choisete=input.nextInt();
                    if (choisete==1){
                        System.out.println(sl.reverse1());}
                    else
                        System.out.println("EXIT");
                    break;
                    
                case 4:  
                    System.out.println("\nTHX FOR YOUR TIME "
                                      +"\nSEE U :)"
                                      +"\n<<<EXIT>>>");
                    System.exit(0);
                break ;
               
                
                default :
                    System.out.println("\nWRONG CHOICE!!\n"
                                     + "PLEASE TRY AGAIN");}}}}   
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        

        
        
        
        
        
        
        
        
 

