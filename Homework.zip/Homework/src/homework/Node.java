
package homework;

class Node <E>{
    
    Node next;
    E data;

    public Node( E data) {
        
        this.next = null;
        this.data = data;}
}