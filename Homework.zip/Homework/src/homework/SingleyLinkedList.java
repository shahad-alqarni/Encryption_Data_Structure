
package homework;

public class SingleyLinkedList<E> {

    Node head = null;   
    Node tail = null;
    int size;
    
    public void addLast(E data) {  
        
        Node newest = new Node(data); 
        
        if(head == null){  
            head = newest;  
            tail = newest;
            size = size +1;}  
        
        else {  
            newest.next= null;
            tail.next = newest;  
            tail = newest;
            size = size +1 ;}  
    }
    
    
    public String reverse2(Node<E> node){
        
        if(node.next==null||node==null)
            return (String)( node.data+"");
        else
            return   reverse2(node.next)+" "+node.data;}
    
    public String reverse1(){
        
        if(head==null)
            return "list is empty"; 
        else
        return reverse2(head);}

    
  
         
   

}
    


  
    
    